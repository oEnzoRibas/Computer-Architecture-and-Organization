// Reference: https://stackoverflow.com/questions/16762167/verilog-order-of-reg

module top;
   initial
     test;
   task test;
      reg[3:0] a[0:1];
      reg[0:3] b[0:1];
      reg[2:5] c[0:1];
      begin
       a[0] = 4'b1101;
       a[1] = 4'b0110;
       a[2] = 4'b0001;                      // error, but not caught by Verilog

       $display("a[2] is %d", a[2]);        // modelsim produces no warning, prints 'a[2] is x'
       $display("a[0][4] is %b", a[0][4]);  // modelsim warns, and prints 'a[0][4] is x'

       $display(                            // produces '1.1.0.1'
         "a[0][3:0] is %b.%b.%b.%b", a[0][3], a[0][2], a[0][1], a[0][0]);

       b[0] = a[0];                         
       $display("b[0] is %d", b[0]);        // produces '13'
       $display(                            // produces '1.1.0.1'
         "b[0][0:3] is %b.%b.%b.%b", b[0][0], b[0][1], b[0][2], b[0][3]);

       c[0] = a[0];                         
       $display("c[0] is %d", c[0]);        // produces '13'
       $display(                            // produces '1.1.0.1'
         "c[0][2:5] is %b.%b.%b.%b", c[0][2], c[0][3], c[0][4], c[0][5]);
     end
   endtask
endmodule
